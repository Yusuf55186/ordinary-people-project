type Props = {
    leftKneeRotation:number
    rightKneeRotation: number
    leftHipRotation:number
    rightHipRotation:number
    leftLegScaleY:number
    rightLegScaleY:number

};
export function YusufLegs({ leftKneeRotation,rightKneeRotation,leftHipRotation,rightHipRotation,rightLegScaleY,leftLegScaleY}:Props){
    
    return (
        
        <svg
          style={{ width: "100%", height: "auto", display: "block", overflow: "visible" }}
viewBox="0 0 188.5 306.17"        >
            
              <defs>
                <clipPath id="CalfClip_L">
    <rect  x="0" y="170" width="188.5" height="134.17"/>
</clipPath>
                <style>{`
                
            
      .cls-1 {
        fill: #d8d8d8;
      }

      .cls-1, .cls-2 {
        stroke-width: 2px;
      }

      .cls-1, .cls-2, .cls-3 {
        stroke: #2a2a2a;
      }

      .cls-2 {
        fill: none;
      }

      .cls-4 {
        fill: rgba(201, 138, 46, 0);
      }

      .cls-5 {
        fill: #e0e0e0;
        isolation: isolate;
        opacity: .6;
      }

      .cls-3 {
        fill: #f5f5f5;
      }

      .cls-3, .cls-6 {
        stroke-width: 2.5px;
      }

      .cls-6 {
        fill: #1a1a2a;
        stroke: #0a0a12;
      }

      .cls-7 {
        fill: #d48455;
        stroke: #000;
        stroke-miterlimit: 10;
      }

      .cls-8 {
        fill: rgba(224, 0, 42, 0);
      }

      .knee-cover {
        fill: #1a1a2a;
        stroke: none;
      }
    `}</style>
    </defs>
    
    <g
  id="Leg_L"
transform={`
  translate(0 0)
  scale(1.06)
  rotate(${leftHipRotation} 50 10)
  translate(50 10)
  scale(1 ${leftLegScaleY})
  translate(-50 -10)
`}>
    <g id="lower_Leg_L" transform={`rotate(${leftKneeRotation} 41 172)`}><g id="Foot_L">
      <path id="Body_Foot_L" className="cls-7" d="M66.43,280.85c-.94-5.29-6.52-7.68-11.98-6.68-4.93.88-10.18,1.97-14.93,3.46-2.43.76-4.56,1.62-6.77,2.4-7.41,2.42-18.74,3.65-24.91,7.4-2.36,1.41-3.34,3.77-1.26,5.23,2.57,1.57,5.19,1.37,9.06,1.72,5.55.37,11.51.56,16.99.3,6.98-.41,14.19-.43,21.11.32,1.82.17,3.55.57,5.34.45,7.01-.77,8.55-9.31,7.37-14.57v-.04Z"/>
      <g id="Shoe_L">
        <g id="Shoe_Sole-2" data-name="Shoe Sole">
          <path className="cls-1" d="M64.27,303.64l-48.18.74c-3,.05-4.83-.61-5.5-1.96-.68-1.93-.49-3.59.55-4.97l56.23.31c1.14,3.48.1,5.44-3.1,5.88Z"/>
        </g>
        <g id="Shoe_Upper-2" data-name="Shoe Upper">
          <path className="cls-3" d="M54.14,276.38c.5-2.57.08-4.98-1.28-7.23-1.32-1.86-3.12-2.23-5.39-1.11l-6.69,4.82c-3.36,2.17-6.1,4.78-8.22,7.84l-22.69,3.52c-4.64.89-7.45,2.63-8.42,5.23-.87,3.96,1.06,5.98,5.78,6.06l65.56,1.13c4.54-2.24,2.46-10.7.99-14.51-1.48-3.8-1.49-5.98-6.18-5.67l-13.46-.08Z"/>
          <path className="cls-5" d="M55.94,277.54l.86,17.81,15.1-.09c4.1-2.48,3.16-6.64,1.74-10.99-1.42-4.34-4.26-6.38-8.53-6.1l-9.17-.64Z"/>
        </g>
        <g id="Shoe_Laces-2" data-name="Shoe Laces">
          <line className="cls-2" x1="38.31" y1="276.45" x2="42.66" y2="270.32"/>
          <line className="cls-2" x1="35.06" y1="276.08" x2="39.34" y2="269.07"/>
          <line className="cls-2" x1="32.45" y1="275.66" x2="36.07" y2="268.41"/>
        </g>
        <ellipse id="Snap_AnkleOpening-2" data-name="Snap AnkleOpening" className="cls-8" cx="42.32" cy="265.96" rx=".96" ry=".88"/>
        <ellipse id="Snap_GroundContact-2" data-name="Snap GroundContact" className="cls-4" cx="55.71" cy="292.87" rx=".96" ry=".88"/>
      </g>
    </g>
<ellipse
  id="KneeCover_L"
  className="knee-cover"
  cx="35"
  cy="172"
  rx="24"
  ry="24"
/>    <g id="Calf_L" clipPath="url(#CalfClip_L)">

            <path id="Body_Calf_L" className="cls-7" d="M58.68,280.3l-4.15-45.68c-.04-.47-.06-.95-.04-1.42.3-7.39,2.31-72.06-20.29-66.93-.36.08-.72.14-1.08.15-3.44.1-24.17,3.47,2.71,73.17.17.43.31.89.42,1.34l10,42.44c.67,2.85,2.44,5.12,4.67,5.79.09.03.18.05.28.08,4.23,1.16,8-3.35,7.49-8.94Z"></path>
            <path id="Pants_Calf_L" className="cls-6" d="M51.87,138.87l18.64,134.19c3.36,21.87-3.65,12.51-7.27,13.44l-9.93,1.86c-3.65.94-10.84-3.37-11.77-7.96l-22.74-91.72-2.81-13.9-1.29-3.92"></path>
            </g>
            </g>
    
    <g id="Thigh_L">
      <path id="Body_Thigh_L" className="cls-7" d="M53.72,51.34l-.58,4.56,2.42.53s10.47.66,15.3,8.95c4.44,7.61-15.27,60.78-18.53,69.43-.29.77-.41,1.62-.34,2.46.51,6.12,2.38,32.48-3.25,35.77-6.37,3.73-14.63,2.81-21.03-2.96,0,0-.46-3.34-.65-7.93-.23-5.55.55-11.15,2.27-16.35,1.09-3.31,2.13-8.2,1.43-13.74-2.25-17.75-6.95-36.9-2.51-54.29,1.97-7.7,4.03-15.04,5.56-18.7,0,0,.44-5.87,18.73-3.34l1.18-4.39Z"/>
      <path id="Pants_Thigh_L" className="cls-6" d="M14.76,171.89l5.39-78.91c0-.26-.02-.52-.05-.77-3.29-27.12-3.03-55.22.79-84.29.51-3.87,3.74-6.74,7.52-6.67l45.1.87c4.1.08,7.37,3.58,7.29,7.81l-1.83,98.08c-.08,4.23-3.47,7.6-7.57,7.52h0c-3.97-.08-7.29,3.08-7.56,7.16l-5.65,57.18"/>
    </g>
  </g>
  <g
  id="Leg_R"
transform={`
  rotate(${rightHipRotation} 116 10)
  translate(116 10)
  scale(1 ${rightLegScaleY})
  translate(-116 -10)
`}>
    <g id="lower_Leg_R" transform={`rotate(${rightKneeRotation} 116 173)`}>
<g id="Foot_R">
      <path id="Body_Foot_R" className="cls-7" d="M127.34,275.97c1.58-5.16,7.43-6.97,12.74-5.41,4.8,1.38,9.89,3,14.44,4.97,2.33,1,4.34,2.07,6.45,3.08,7.08,3.17,18.2,5.55,23.88,9.9,2.18,1.65,2.86,4.09.61,5.33-2.76,1.3-5.33.83-9.22.78-5.57-.2-11.52-.62-16.94-1.44-6.89-1.12-14.07-1.88-21.05-1.85-1.83-.02-3.6.2-5.37-.1-6.88-1.49-7.36-10.13-5.54-15.23v-.04Z"/>
      <g id="Shoe_R">
        <g id="Shoe_Sole" data-name="Shoe Sole">
          <path className="cls-1" d="M120.7,295.63l56.23,2.86c.95,1.43,1.03,3.1.22,4.99-.76,1.31-2.63,1.86-5.63,1.65l-48.11-3.44c-3.17-.62-4.08-2.63-2.71-6.05Z"/>
        </g>
        <g id="Shoe_Upper" data-name="Shoe Upper">
          <path className="cls-3" d="M121.9,274.36c-4.67-.57-4.83,1.6-6.56,5.32-1.73,3.71-4.37,12.04.02,14.53l65.6,2.56c4.72.18,6.78-1.73,6.18-5.72-.8-2.65-3.49-4.54-8.07-5.69l-18.31-7.77c-1.91-3.17-8.6-2.95-11.82-5.31l-6.36-5.19c-2.19-1.25-4.01-.98-5.46.81-1.51,2.17-2.09,4.55-1.76,7.14l-13.46-.68Z"/>
          <path className="cls-5" d="M124.27,276.22c-4.25-.52-7.23,1.35-8.94,5.61-1.71,4.26-2.92,8.35,1.01,11.06l15.09.93,2.05-17.73-9.21.12Z"/>
        </g>
        <g id="Shoe_Laces" data-name="Shoe Laces">
          <line className="cls-2" x1="147.23" y1="269.64" x2="151.17" y2="276"/>
          <line className="cls-2" x1="150.63" y1="268.58" x2="154.44" y2="275.81"/>
          <line className="cls-2" x1="153.95" y1="268.1" x2="157.08" y2="275.54"/>
        </g>
        <ellipse id="Snap_AnkleOpening" data-name="Snap AnkleOpening" className="cls-8" cx="147.87" cy="265.3" rx=".88" ry=".97" transform="translate(-118.39 411.44) rotate(-89.63)"/>
        <ellipse id="Snap_GroundContact" data-name="Snap GroundContact" className="cls-4" cx="132.68" cy="291.41" rx=".88" ry=".97" transform="translate(-159.58 422.2) rotate(-89.63)"/>
      </g>
    </g>
    <ellipse id="KneeCover_R" className="knee-cover" cx="130" cy="173" rx="22" ry="24" transform="rotate(9 116 173)"/>
    <g id="Calf_R">
      <path id="Body_Calf_R" className="cls-7" d="M125.35,265.07l-9.26-37.64c-.1-.39-.22-.77-.38-1.14-2.49-5.77-23.5-56.18.73-60.25.38-.06.76-.15,1.13-.27,3.49-1.16,25.34-5.96,18.79,58.87-.04.4-.05.81-.02,1.21l2.42,37.11c.17,2.63-1.07,5.14-3.24,6.49-.05.03-.09.06-.14.09-3.89,2.36-8.9.07-10.02-4.47Z"/>
      <path id="Pants_Calf_R" className="cls-6" d="M143.21,185.32l3.49,79.36c.22,3.81-3.16,7.2-7.65,7.67l-11.32,1.82c-4.45.47-10.81,7.02-11.4,3.29l-17.71-109.43,45.87-9.06-1.28,26.36Z"/>
    </g>
    </g>    
    <g id="Thigh_R">
      <path id="Body_Thigh_R" className="cls-7" d="M108.03,49.13l.23,2.47c.11,1.18-.72,2.25-1.9,2.43l-.47.07c-.09.01-.18.02-.27.03-1.3.05-11.85.69-17.24,8.26-5.18,7.27,13.4,59.5,17.09,69.68.41,1.12.53,2.32.37,3.5-.95,6.94-3.92,31.91,2,35.36,6.65,3.88,15.46,3.49,22.69-1.48.49-.34.82-.88.92-1.47.23-1.29.63-3.84.92-6.96.51-5.53-.09-11.16-1.75-16.44-1.06-3.36-1.98-8.29-.94-13.79,3.32-17.64,9.43-36.55,5.31-54.12-1.82-7.78-3.76-15.2-5.28-18.93,0,0-.21-5.88-20.59-4.17"/>
      <path id="Pants_Thigh_R" className="cls-6" d="M137.48,185.18l3.8-12.47c.06-.2.14-.38.24-.55.53-.86,2.81-10,2.86-10.58.37-4.56.98-12.21.89-13.43l-2.42-47.19c.02-.27.05-.55.09-.82,4.38-27.94,5.49-57.01,3.31-87.22-.38-5.28-4.28-9.35-9.01-9.46l-40.18-.95c-5.14-.12-9.42,4.44-9.58,10.19l-2.65,98.21c-.12,4.49,3.9,11.45,6.95,11.69h0c3.87.09,6.97,3.57,7.04,7.91l-1.65,37.47"/>
    </g>
  </g>
  
        </svg>
      
    );
}